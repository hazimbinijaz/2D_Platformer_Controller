﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Parallax : MonoBehaviour
{
    // Start is called before the first frame update
    private float length, starposition;
    public GameObject cam;
    public float parallax;
    void Start()
    {
        starposition = transform.position.x;
        length = GetComponent<SpriteRenderer>().bounds.size.x;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        float temp = (cam.transform.position.x * (1 - parallax));
        float distance = (cam.transform.position.x * parallax);
        transform.position = new Vector3(starposition+distance,transform.position.y,transform.position.z);

        if (temp > starposition + length)
            starposition += length;
        else if (temp < starposition - length)
            starposition -= length;
    
    }
}
