﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    // Start is called before the first frame update
    public int MovSpeed;
    public int JumpForce;
    int MaxJumps;
    bool IsRun;
    public Rigidbody2D PlayerBody;
    [SerializeField] Collider2D GroundCheckCollider;
    [SerializeField] Animator PlayerAnimator;
    SpriteRenderer SP;
    bool IsGrounded;
    public ParticleSystem DashEffect1;
    public ParticleSystem DashEffect2;
    void Start()
    {
        IsRun = false;
        MovSpeed = 8;
        IsGrounded = false;
        JumpForce = 200;
        MaxJumps = 2;
        SP=GetComponentInChildren<SpriteRenderer>();
    }

    // Update is called once per frame
    void Update()
    {
        CheckIfGrounded();
        if(IsGrounded==true)
        {
            
            MaxJumps = 2;
            PlayerAnimator.SetBool("IsJumping", false);
            
            
        }

        else
            PlayerAnimator.SetBool("IsJumping", true);

        if (Input.GetKeyDown(KeyCode.Space))
        {
            MaxJumps--;
            Jump();
        }   
        Move();

        if (Input.GetKeyDown(KeyCode.E))
        {
            Attack();
        }

    }

    public void Attack()
    {
        StartCoroutine(AttackCoroutine());

    }

    IEnumerator AttackCoroutine()
    {
        PlayerAnimator.SetBool("HasAttacked", true);
        yield return new WaitForSecondsRealtime(0.165f);
        PlayerAnimator.SetBool("HasAttacked", false);
        yield return null;
    }

    public void Jump()
    {
        
        if (IsGrounded || MaxJumps == 1)
        {
            StartCoroutine(JumpCoroutine());
            
        }
        if(MaxJumps==0)
        {
            Dash();
        }
    }

    public void Dash()
    {
        
        if(SP.flipX)
        { 
            PlayerBody.AddForce(Vector3.left *7,ForceMode2D.Impulse);
            DashEffect2.Play();
        }
        else
        {
            PlayerBody.AddForce(Vector3.right *7, ForceMode2D.Impulse);
            DashEffect1.Play();

        }

    }

    IEnumerator JumpCoroutine()
    {
        
        PlayerBody.velocity = Vector2.zero;
        PlayerBody.AddForce(Vector3.up * JumpForce);
        //yield return new WaitForSeconds(0.1f);
        while (PlayerBody.velocity.y > 0)
        {
            yield return null;
            
        }
        
       


    }

    public void CheckIfGrounded()
    {
        ContactFilter2D filter2d = new ContactFilter2D();
        List<Collider2D> results = new List<Collider2D>();
        GroundCheckCollider.OverlapCollider(filter2d, results);
        IsGrounded = (results.Count > 0);
    }

    public void Move()
    {
        float HorizontalAxis = Input.GetAxis("Horizontal");
        Vector3 MyPosition = transform.position;
        Flipper(HorizontalAxis);
        IsRun = HorizontalAxis != 0 ? true : false;
        PlayerAnimator.SetBool("IsRunning", IsRun);

        MyPosition.x += HorizontalAxis * Time.deltaTime * MovSpeed;
        transform.position = MyPosition;

    }

    private void Flipper(float HorizontalAxis)
    {
        if (HorizontalAxis > 0)
        {
            SP.flipX = false;
        }

        else if (HorizontalAxis < 0)
        {
            SP.flipX = true;
        }
    }

}
